# PineconeBot

Geode mod source project for Geometry Dash. Target: Android arm32/arm64, with a touch-sized popup.

## Features in this source
- GDR2 replay serialization via `maxnut/GDReplayFormat`.
- Frame-based record/playback of player inputs.
- Save and load `.gdr2` macros in Geode's save directory (`macros/`).
- Continue appends new events after the most recent release event.
- Name filtering for saved macros.
- Event editor: move through events, change the frame, and toggle press/release.
- User-provided SVG icon converted to `logo.png`.

## Build
Requires the Geode v5 SDK/CLI, Android NDK, and Geode Android binaries:

```sh
geode sdk install-binaries -p android64
geode build -p android64
```

Use `android32` for 32-bit devices. The `.geode` output is produced in `build-android64` or `build-android32`.

## Build status
This environment does not contain the Geode SDK/Android NDK, so I could not compile or test the binary here. Treat this as a first source implementation, not a verified installable `.geode` package. In particular, the `PlayLayer::handleButton` binding and runtime behavior need validation against the exact Geometry Dash/Geode build on device.
