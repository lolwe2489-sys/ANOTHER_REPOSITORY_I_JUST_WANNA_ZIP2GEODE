#include <Geode/Geode.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include <Geode/modify/MenuLayer.hpp>
#include <gdr/gdr.hpp>
#include <filesystem>
#include <fstream>
#include <algorithm>
#include <cctype>
#include <iterator>

using namespace geode::prelude;
namespace fs = std::filesystem;

// PineconeBot deliberately keeps replay data in the standard GDR2 container.
// Inputs: button 1 = jump, 2 = left, 3 = right; down=false is a release.
namespace pinecone {
    using Replay = gdr::Replay<>;
    enum class Mode { Idle, Recording, Playing };

    struct State {
        Mode mode = Mode::Idle;
        Replay replay{"PineconeBot", 1};
        uint64_t frame = 0;
        uint64_t continueOffset = 0;
        size_t playIndex = 0;
        bool injecting = false;
        std::string selected;
        std::string search;
        std::vector<std::string> files;

        fs::path folder() const {
            auto p = Mod::get()->getSaveDir() / "macros";
            std::error_code ec;
            fs::create_directories(p, ec);
            return p;
        }
        void refresh() {
            files.clear();
            std::error_code ec;
            for (auto const& e : fs::directory_iterator(folder(), ec)) {
                if (e.is_regular_file() && e.path().extension() == ".gdr2")
                    files.push_back(e.path().filename().string());
            }
            std::sort(files.begin(), files.end());
        }
        std::vector<std::string> filtered() const {
            std::vector<std::string> out;
            auto q = search;
            std::transform(q.begin(), q.end(), q.begin(), [](unsigned char c) { return (char)std::tolower(c); });
            for (auto const& f : files) {
                auto n = f;
                std::transform(n.begin(), n.end(), n.begin(), [](unsigned char c) { return (char)std::tolower(c); });
                if (q.empty() || n.find(q) != std::string::npos) out.push_back(f);
            }
            return out;
        }
        bool save(std::string name) {
            if (name.empty()) return false;
            if (name.size() > 80) name.resize(80);
            for (auto& c : name) if (!(std::isalnum((unsigned char)c) || c == '-' || c == '_' || c == ' ')) c = '_';
            auto result = replay.exportData(folder() / (name + ".gdr2"));
            if (result.isErr()) {
                log::error("PineconeBot save failed: {}", result.unwrapErr());
                return false;
            }
            refresh(); selected = name + ".gdr2"; return true;
        }
        bool load(std::string const& name) {
            std::ifstream in(folder() / name, std::ios::binary);
            if (!in) return false;
            std::vector<uint8_t> bytes((std::istreambuf_iterator<char>(in)), {});
            auto parsed = Replay::importData(bytes);
            if (parsed.isErr()) {
                log::error("PineconeBot load failed: {}", parsed.unwrapErr());
                return false;
            }
            replay = std::move(parsed.unwrap()); selected = name;
            frame = 0; playIndex = 0; return true;
        }
        void startRecord(bool append) {
            if (append && !replay.inputs.empty()) {
                // Continue from the last release event, not from the final press.
                auto it = std::find_if(replay.inputs.rbegin(), replay.inputs.rend(), [](auto const& i) { return !i.down; });
                continueOffset = it == replay.inputs.rend() ? replay.inputs.back().frame + 1 : it->frame + 1;
            } else {
                replay = Replay{"PineconeBot", 1};
                replay.author = "bebebe";
                replay.framerate = 240.0;
                continueOffset = 0;
            }
            frame = 0; mode = Mode::Recording;
        }
        void stop() { if (mode == Mode::Recording) replay.duration = float((continueOffset + frame) / replay.framerate); mode = Mode::Idle; }
    };
    inline State g;
}

// A compact touch-first control popup with searchable macro names and an event editor.
class PineconePopup : public geode::Popup, public TextInputDelegate {
    CCTextInputNode* m_search = nullptr;
    CCTextInputNode* m_name = nullptr;
    CCLabelBMFont* m_editorLabel = nullptr;
    size_t m_editIndex = 0;

    CCMenuItemSpriteExtra* button(CCMenu* menu, char const* text, SEL_MenuHandler fn, CCPoint pos, float width = 82.f) {
        auto item = CCMenuItemSpriteExtra::create(
            ButtonSprite::create(text, width, true, "goldFont.fnt", "GJ_button_01.png", 28, 0.7f), this, fn);
        item->setPosition(pos); menu->addChild(item); return item;
    }
    void refreshEditor() {
        auto& inputs = pinecone::g.replay.inputs;
        if (!m_editorLabel) return;
        if (inputs.empty()) { m_editorLabel->setString("No events"); return; }
        m_editIndex = std::min(m_editIndex, inputs.size() - 1);
        auto const& e = inputs[m_editIndex];
        auto line = fmt::format("Event {}/{}  |  frame {}  |  button {}  |  {}",
            m_editIndex + 1, inputs.size(), e.frame, e.button, e.down ? "DOWN" : "UP");
        m_editorLabel->setString(line.c_str());
    }
    void refreshSearch() {
        pinecone::g.search = m_search ? m_search->getString() : "";
    }
protected:
    bool init() {
        if (!Popup::init(350.f, 260.f)) return false;
        this->setTitle("PineconeBot");
        auto menu = CCMenu::create(); menu->setPosition({0, 0}); this->addChild(menu);

        button(menu, "Record", menu_selector(PineconePopup::onRecord), {-112, 82}, 92);
        button(menu, "Play", menu_selector(PineconePopup::onPlay), {0, 82}, 92);
        button(menu, "Continue", menu_selector(PineconePopup::onContinue), {112, 82}, 92);
        button(menu, "Save", menu_selector(PineconePopup::onSave), {-112, 35}, 92);
        button(menu, "Load", menu_selector(PineconePopup::onLoad), {0, 35}, 92);
        button(menu, "Edit", menu_selector(PineconePopup::onEdit), {112, 35}, 92);

        auto searchLabel = CCLabelBMFont::create("Search", "goldFont.fnt");
        searchLabel->setScale(0.42f); searchLabel->setPosition({-130, -8}); this->addChild(searchLabel);
        m_search = CCTextInputNode::create(205, 24, "Search macros by name", "bigFont.fnt");
        m_search->setPosition({20, -8}); m_search->setDelegate(this); this->addChild(m_search);
        auto nameLabel = CCLabelBMFont::create("Save as", "goldFont.fnt");
        nameLabel->setScale(0.42f); nameLabel->setPosition({-130, -42}); this->addChild(nameLabel);
        m_name = CCTextInputNode::create(205, 24, "Macro name", "bigFont.fnt");
        m_name->setPosition({20, -42}); this->addChild(m_name);

        button(menu, "<", menu_selector(PineconePopup::onPrevEvent), {-110, -83}, 38);
        button(menu, "Frame -", menu_selector(PineconePopup::onFrameMinus), {-52, -83}, 66);
        button(menu, "Frame +", menu_selector(PineconePopup::onFramePlus), {25, -83}, 66);
        button(menu, "Next >", menu_selector(PineconePopup::onNextEvent), {110, -83}, 48);
        button(menu, "Down/Up", menu_selector(PineconePopup::onToggle), {0, -119}, 90);
        m_editorLabel = CCLabelBMFont::create("No events", "goldFont.fnt");
        m_editorLabel->setScale(0.38f); m_editorLabel->setPosition({0, -62}); this->addChild(m_editorLabel);
        refreshEditor();
        return true;
    }
    void textChanged(CCTextInputNode* node) override {
        if (node == m_search) refreshSearch();
    }
    void onRecord(CCObject*) {
        if (pinecone::g.mode == pinecone::Mode::Recording) pinecone::g.stop();
        else pinecone::g.startRecord(false);
    }
    void onPlay(CCObject*) {
        if (pinecone::g.replay.inputs.empty()) { FLAlertLayer::create("PineconeBot", "Load or record a macro first.", "OK")->show(); return; }
        pinecone::g.frame = 0; pinecone::g.playIndex = 0; pinecone::g.mode = pinecone::Mode::Playing;
    }
    void onContinue(CCObject*) { pinecone::g.startRecord(true); }
    void onSave(CCObject*) {
        auto name = m_name ? m_name->getString() : "";
        if (name.empty()) name = pinecone::g.replay.levelInfo.name;
        if (name.empty()) name = "PineconeMacro";
        if (!pinecone::g.save(name)) FLAlertLayer::create("PineconeBot", "Couldn't save the macro.", "OK")->show();
    }
    void onLoad(CCObject*) {
        refreshSearch(); pinecone::g.refresh();
        auto list = pinecone::g.filtered();
        if (list.empty()) { FLAlertLayer::create("PineconeBot", "No matching .gdr2 macros found.", "OK")->show(); return; }
        if (!pinecone::g.load(list.front())) FLAlertLayer::create("PineconeBot", "This macro could not be loaded.", "OK")->show();
        m_editIndex = 0; refreshEditor();
    }
    void onEdit(CCObject*) { refreshEditor(); }
    void onPrevEvent(CCObject*) { if (m_editIndex) --m_editIndex; refreshEditor(); }
    void onNextEvent(CCObject*) { if (m_editIndex + 1 < pinecone::g.replay.inputs.size()) ++m_editIndex; refreshEditor(); }
    void onFrameMinus(CCObject*) {
        auto& v = pinecone::g.replay.inputs;
        if (!v.empty() && v[m_editIndex].frame > 0) { --v[m_editIndex].frame; pinecone::g.replay.sortInputs(); refreshEditor(); }
    }
    void onFramePlus(CCObject*) {
        auto& v = pinecone::g.replay.inputs;
        if (!v.empty()) { ++v[m_editIndex].frame; pinecone::g.replay.sortInputs(); refreshEditor(); }
    }
    void onToggle(CCObject*) {
        auto& v = pinecone::g.replay.inputs;
        if (!v.empty()) { v[m_editIndex].down = !v[m_editIndex].down; refreshEditor(); }
    }
public:
    static PineconePopup* create() {
        auto ret = new PineconePopup();
        if (ret->init()) { ret->autorelease(); return ret; }
        delete ret; return nullptr;
    }
};

class $modify(PineconePlayLayer, PlayLayer) {
    void onEnter() {
        PlayLayer::onEnter();
        auto size = CCDirector::sharedDirector()->getWinSize();
        auto menu = CCMenu::create();
        menu->setPosition({0, 0});
        auto item = CCMenuItemSpriteExtra::create(
            ButtonSprite::create("Pinecone", 68, true, "goldFont.fnt", "GJ_button_01.png", 28, 0.65f),
            this, menu_selector(PineconePlayLayer::onPinecone));
        item->setPosition({size.width - 48.f, size.height - 26.f});
        menu->addChild(item);
        this->addChild(menu, 1000);
    }
    void onPinecone(CCObject*) { PineconePopup::create()->show(); }

    void update(float dt) {
        PlayLayer::update(dt);
        auto& s = pinecone::g;
        if (s.mode == pinecone::Mode::Idle) return;
        if (s.mode == pinecone::Mode::Playing) {
            while (s.playIndex < s.replay.inputs.size() && s.replay.inputs[s.playIndex].frame <= s.frame) {
                auto const e = s.replay.inputs[s.playIndex++];
                s.injecting = true;
                this->handleButton(e.down, e.button, !e.player2);
                s.injecting = false;
            }
            if (s.playIndex >= s.replay.inputs.size()) s.mode = pinecone::Mode::Idle;
        }
        ++s.frame;
    }
    void handleButton(bool down, int button, bool isPlayer1) {
        auto& s = pinecone::g;
        if (!s.injecting && s.mode == pinecone::Mode::Recording) {
            auto frame = s.continueOffset + s.frame;
            s.replay.inputs.emplace_back(frame, (uint8_t)button, !isPlayer1, down);
            if (auto pl = PlayLayer::get()) {
                if (pl->m_level) {
                    s.replay.levelInfo.id = pl->m_level->m_levelID;
                    s.replay.levelInfo.name = pl->m_level->m_levelName;
                }
            }
        }
        PlayLayer::handleButton(down, button, isPlayer1);
    }
};

class $modify(PineconeMenuLayer, MenuLayer) {
    bool init() {
        if (!MenuLayer::init()) return false;
        auto menu = this->getChildByID("bottom-menu");
        if (menu) {
            auto item = CCMenuItemSpriteExtra::create(
                ButtonSprite::create("Pinecone", 70, true, "goldFont.fnt", "GJ_button_01.png", 30, 0.7f),
                this, menu_selector(PineconeMenuLayer::onPinecone));
            item->setID("pineconebot/open-button");
            item->setScale(0.42f);
            menu->addChild(item);
            menu->updateLayout();
        }
        return true;
    }
    void onPinecone(CCObject*) { PineconePopup::create()->show(); }
};
