# PineconeBot

A compact Geometry Dash replay recorder/player for Geode, designed with touch controls in mind. Stores replay data in the GDR2 format.
